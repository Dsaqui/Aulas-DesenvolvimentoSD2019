public class Principal {

    public static void main(String[] args) {

        Banheiro banheiro = new Banheiro();

        //Instanciando objetos de Thread e passando o nome do Thread
        Thread convidado1 = new Thread(new TarefaNumero1(banheiro), "Cleber");
        Thread convidado2 = new Thread(new TarefaNumero2(banheiro), "Thiago");
        Thread limpeza = new Thread(new TarefaLimpeza(banheiro), "Limpeza");
        
        //s� funciona se outra thread estiver funcionando.
        limpeza.setDaemon(true);
        
        //iniciando thread
        convidado1.start();
        convidado2.start();
        limpeza.start();
    }
}