//implementa interface runnable
public class TarefaNumero1 implements Runnable {

    private Banheiro banheiro;

    public TarefaNumero1(Banheiro banheiro) {
        this.banheiro = banheiro;
    }

    //quanto essa classe for chama vai ser executada por aqui
    @Override
    public void run() {
        this.banheiro.fazNumero1();
    }
}