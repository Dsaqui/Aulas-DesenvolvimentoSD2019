public class Banheiro {
    private boolean ehSujo = true;

	public void fazNumero1() {
		//pega o nome da Thread
	    String nome = Thread.currentThread().getName();
	    System.out.println(nome + " batendo na porta");
	    //indica que o bloco dentro desse c�digo � executado em concorrencia    
	    synchronized (this) {
	        System.out.println(nome + " entrando no banheiro");
	        //tem que ser While - pq ele tem que ficar verificando se � sujo ou limpo, se colocar o IF ele vai sair da thread e continuar depois, com while tem que ficar verificando.
	        while (this.ehSujo) {
	            esperaLaFora(nome);
			    System.out.println(nome + ", est� entrando novamente");
	        }
	        System.out.println(nome + " fazendo coisa rapida");
	        dormeUmPouco(5000);
	        this.ehSujo=true;
	        System.out.println(nome + " dando descarga");
	        System.out.println(nome + " lavando a mao");
	        System.out.println(nome + " saindo do banheiro");
	    }
	}

	private void dormeUmPouco(long milli) {
		try {
		    Thread.sleep(milli);
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}
	}

	public void fazNumero2() {


	    String nome = Thread.currentThread().getName();

	    System.out.println(nome + " batendo na porta");

	    synchronized (this) {

	        System.out.println(nome + " entrando no banheiro");

	        while (this.ehSujo) {
	            esperaLaFora(nome);
			    System.out.println(nome + ", est� entrando novamente");
	        }
	        
	        System.out.println(nome + " fazendo coisa demorada");

	        dormeUmPouco(5000);

	        
	        this.ehSujo=true;
	        System.out.println(nome + " dando descarga");
	        System.out.println(nome + " lavando a mao");
	        System.out.println(nome + " saindo do banheiro");
	    }
	}
	
	private void esperaLaFora(String nome) {
	    System.out.println(nome + ", eca, banheiro est� sujo, vou esperar limpeza l� fora");
	    try {
	    	//wait() interrompe a thread atual, coloca a mesma para �dormir� sem tempo determinado at� que uma outra thread use o m�todo notify() para acordar ela
	        this.wait();
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }
	}

	public void limpa() {

	    String nome = Thread.currentThread().getName();

	    System.out.println(nome + " batendo na porta");

	    synchronized (this) {

	        System.out.println(nome + " entrando no banheiro");

	        if (!this.ehSujo) {
	            System.out.println(nome + ", n�o est� sujo, vou sair");
	            return;
	        }

	        System.out.println(nome + " limpando o banheiro");
	        //limpa
	        this.ehSujo = false;

	        try {
	            Thread.sleep(13000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        //notifica todos
	        this.notifyAll();

	        System.out.println(nome + " saindo do banheiro");
	    }
	}
}